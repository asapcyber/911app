# Placeholder app.py that prints 'Hello World'
import streamlit as st
st.write('Hello from deployed app')
